package com.example.laboratorio5.ui.Resultados

import androidx.lifecycle.ViewModel

class ResultadosViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}
