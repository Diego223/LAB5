package com.example.laboratorio5.ui.AddQuestion

import android.content.Context
import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import android.text.TextUtils
import android.view.*
import android.widget.TextView
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.fragment.app.Fragment
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.example.laboratorio5.MainActivity
import com.example.laboratorio5.databinding.AddQuestionFragmentBinding

import com.example.laboratorio5.R
import com.example.laboratorio5.SharedView
import com.example.laboratorio5.ui.home.HomeViewModel
import com.example.laboratorio5.ui.questions.QuestionFragment
import kotlinx.android.synthetic.main.add_question_fragment.*
import kotlinx.android.synthetic.main.question_fragment.*

class addQuestion : Fragment() , View.OnClickListener{


    private val HomeUriModel by lazy {
        ViewModelProviders.of(activity!!).get(SharedView::class.java)
    }


    lateinit var databinding: AddQuestionFragmentBinding
    lateinit var navController: NavController
    private lateinit var homeViewModel: HomeViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    companion object {
        fun newInstance() = addQuestion()
    }

    private lateinit var viewModel: AddQuestionViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        databinding = DataBindingUtil.inflate(inflater, R.layout.add_question_fragment, container, false)

        return databinding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(AddQuestionViewModel::class.java)

    }
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        (activity as MainActivity).supportActionBar?.title = "Agregar pregunta"

    }

    override fun onClick(v: View?) {

    }
    //Esto es para mostrar el toolbar
    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        inflater.inflate(R.menu.guardar,menu);
        super.onCreateOptionsMenu(menu, inflater)
    }
    //Se le da la accion de ir a el fragment de la biografia cuando apacha el boton del toolbar
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId;
        if (id == R.id.guardado){
                if(!TextUtils.isEmpty(preguntaAdd.text.toString())){
                    HomeUriModel.mutableList.remove("Alguna sugerencia?")
                    HomeUriModel.mutableList.add(preguntaAdd.text.toString())
                    Toast.makeText(activity!!.applicationContext, "Tu pregunta se guardo", Toast.LENGTH_LONG).show()
                    navController.navigate(R.id.action_addQuestion_to_nav_home)
                }
        }
        return super.onOptionsItemSelected(item)
    }




}
