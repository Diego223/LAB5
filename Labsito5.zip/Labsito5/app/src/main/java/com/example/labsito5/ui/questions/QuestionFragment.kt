package com.example.laboratorio5.ui.questions

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.databinding.DataBindingUtil
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.example.laboratorio5.MainActivity

import com.example.laboratorio5.R
import com.example.laboratorio5.SharedView
import com.example.laboratorio5.databinding.QuestionFragmentBinding
import com.google.android.material.floatingactionbutton.FloatingActionButton
import kotlinx.android.synthetic.main.question_fragment.*

class QuestionFragment : Fragment(),View.OnClickListener {

    private val SharedView by lazy {
        ViewModelProviders.of(activity!!).get(SharedView::class.java)
    }
    private val viewModel by lazy{
        ViewModelProviders.of(this).get(QuestionViewModel::class.java)
    }
    lateinit var databinding: QuestionFragmentBinding
    lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }

    companion object {
        fun newInstance() = QuestionFragment()
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        databinding = DataBindingUtil.inflate(inflater, R.layout.question_fragment, container, false)
        return databinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        view.findViewById<Button>(R.id.next).setOnClickListener(this)
        if(SharedView.visibility == View.VISIBLE){
            (activity as MainActivity).supportActionBar?.title = "Survey app"
            databinding.ratingBar.visibility = View.VISIBLE
            databinding.respuesta.visibility = View.INVISIBLE
        }else {
            Preguntas.text = SharedView.mutableList[SharedView.cont - 1]
            (activity as MainActivity).supportActionBar?.title =
                "Encuestas(" + (SharedView.cont) + "/" + SharedView.mutableList.size + ")"
        }
    }


    override fun onClick(v: View?) {
        when(v!!.id){
            R.id.next -> {
                if (SharedView.cont < SharedView.mutableList.size) {
                    res.setText("")
                    Preguntas.text = SharedView.mutableList[SharedView.cont]
                    (activity as MainActivity).supportActionBar?.title =
                        "Encuestas (" + (SharedView.cont + 1) + "/" + SharedView.mutableList.size + ")"
                    val a = "Question " + (SharedView.cont) + " - " + res.text.toString()
                    SharedView.res = SharedView.res + a
                }
                if (SharedView.cont == SharedView.mutableList.size) {
                    val a = "Question " + (SharedView.cont) + " - " + res.text.toString()
                    SharedView.res = SharedView.res + a
                }
                if (SharedView.cont+1 > SharedView.mutableList.size){
                    if (ratingBar.visibility == View.INVISIBLE){
                        (activity as MainActivity).supportActionBar?.title = "Encuestas"
                        SharedView.visibility = View.VISIBLE
                        ratingBar.visibility = View.VISIBLE
                        res.visibility = View.INVISIBLE
                    }
                    else{
                        navController.navigate(R.id.action_questionFragment_to_resultadosFragment)
                        SharedView.rating = ratingBar.rating.toString()
                    }
                }
                SharedView.cont++
            }
        }

    }

}
