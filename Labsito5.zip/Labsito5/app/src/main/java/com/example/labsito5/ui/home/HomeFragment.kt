package com.example.laboratorio5.ui.home

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.Fragment
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.navigation.NavController
import androidx.navigation.Navigation
import androidx.navigation.findNavController
import com.example.laboratorio5.MainActivity
import com.example.laboratorio5.R
import com.example.laboratorio5.SharedView
import com.example.laboratorio5.databinding.FragmentHomeBinding
import com.example.laboratorio5.ui.questions.QuestionFragment
import com.example.laboratorio5.ui.questions.QuestionViewModel
import com.google.android.material.floatingactionbutton.FloatingActionButton

class HomeFragment : Fragment(), View.OnClickListener{
    private val SharedView by lazy {
        ViewModelProviders.of(activity!!).get(SharedView::class.java)
    }
    lateinit var navController: NavController
    private lateinit var homeViewModel: HomeViewModel
    lateinit var binding : FragmentHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        homeViewModel =
            ViewModelProviders.of(this).get(HomeViewModel::class.java)
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false)

        binding.iniciarencuesta.setOnClickListener {
            SharedView.encuesta++
            SharedView.cont = 1
            SharedView.visibility = View.INVISIBLE
            SharedView.res = SharedView.res + "Preguntas " + SharedView.encuesta + ":"
            if ("Alguna sugerencia?" in SharedView.mutableList){

            }else{
                SharedView.mutableList.add("Alguna sugerencia?")
            }

            navController.navigate(R.id.action_nav_home_to_questionFragment)
        }
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        view.findViewById<FloatingActionButton>(R.id.fab).setOnClickListener(this)

    }
    override fun onClick(v: View?) {
        when(v!!.id) {
            R.id.fab -> {
                navController.navigate(R.id.action_nav_home_to_addQuestion)

            }
        }

    }


}