package com.example.laboratorio5.ui.questions

import android.app.Activity
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.laboratorio5.MainActivity

class QuestionViewModel : ViewModel() {

}

