package com.example.laboratorio5.ui.Resultados

import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.navigation.NavController
import androidx.navigation.Navigation
import com.example.laboratorio5.MainActivity

import com.example.laboratorio5.R
import com.example.laboratorio5.SharedView
import com.example.laboratorio5.databinding.ResultadosFragmentBinding
import kotlinx.android.synthetic.main.question_fragment.*

class ResultadosFragment : Fragment(), View.OnClickListener{
    lateinit var databinding: ResultadosFragmentBinding
    lateinit var navController: NavController
    var junto: String = ""
    private val SharedView by lazy {
        ViewModelProviders.of(activity!!).get(SharedView::class.java)
    }

    companion object {
        fun newInstance() = ResultadosFragment()
    }

    private lateinit var viewModel: ResultadosViewModel



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setHasOptionsMenu(true)
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        databinding = DataBindingUtil.inflate(inflater, R.layout.resultados_fragment, container, false)

        databinding.nuevaEncuesta.setOnClickListener {
            SharedView.encuestaVeces++
            if ("Alguna sugerencia?" in SharedView.mutableList){

            }else{
                SharedView.mutableList.add("¿Tiene algún comentario o sugerencia?")
            }
            SharedView.cont = 1
            SharedView.visibility = View.INVISIBLE
            SharedView.res = SharedView.res + "Encuesta " + SharedView.encv + ":"
            navController.navigate(R.id.action_resultadosFragment_to_questionFragment)

        }
        databinding.resv.setOnClickListener {
            Toast.makeText(activity!!.applicationContext, SharedView.res, Toast.LENGTH_LONG).show()
        }

        return databinding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        viewModel = ViewModelProviders.of(this).get(ResultadosViewModel::class.java)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        navController = Navigation.findNavController(view)
        databinding.rating.text = "Valoracion: " + SharedView.rating
        databinding.encn.text = "Encuestas: " + SharedView.encv.toString()
    }
    override fun onClick(v: View?) {

    }

}
